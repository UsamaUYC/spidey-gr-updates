const LOCAL_SERVER_URL = "http://127.0.0.1:4477/device";
const RELOAD_CHECK_URL = "http://127.0.0.1:4477/reload-extension";

const PROJECT_ID = "spidey-greece";
const FIREBASE_BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;
const DEVICES_URL = `${FIREBASE_BASE}/devices/`;

/* ---------------------------------- */
/*       EXTENSION RELOAD CHECK       */
/* ---------------------------------- */

let lastReloadTime = 0;

async function checkForReloadSignal() {

  try {

    const res = await fetch(RELOAD_CHECK_URL, { cache: "no-store" });

    if (!res.ok) return;

    const data = await res.json();

    if (data.reload === true) {

      const now = Date.now();

      // prevent reload spam
      if (now - lastReloadTime < 10000) return;

      lastReloadTime = now;

      console.log("🔄 Reload signal received from local app");

      chrome.runtime.reload();

    }

  } catch (err) {

    // silent fail if local app not running

  }

}

// run once immediately
checkForReloadSignal();

// then poll every 5 seconds
setInterval(checkForReloadSignal, 5000);


/* ---------------------------------- */
/*          LOCAL DEVICE CHECK        */
/* ---------------------------------- */

async function getLocalDeviceInfo(retries = 3) {

  for (let i = 0; i < retries; i++) {

    try {

      const res = await fetch(LOCAL_SERVER_URL, { cache: "no-store" });

      if (res.ok) return await res.json();

    } catch (err) {

      // silent retry
      await new Promise(r => setTimeout(r, 1500));

    }

  }

  return null;

}


/* ---------------------------------- */
/*      FIRESTORE APPROVAL CHECK      */
/* ---------------------------------- */

async function isDeviceApproved(deviceId) {

  try {

    const res = await fetch(DEVICES_URL + deviceId);

    if (!res.ok) return false;

    const json = await res.json();

    const approved = json.fields?.approved?.booleanValue === true;

    chrome.storage.local.set({ deviceApproved: approved });

    return approved;

  } catch (err) {

    console.error("Error checking approval:", err);

    return false;

  }

}


/* ---------------------------------- */
/*        NOTIFICATION HELPER         */
/* ---------------------------------- */

async function showNotificationOnce(title, message, key) {

  const data = await chrome.storage.local.get(key);

  if (data[key]) return;

  chrome.notifications.create({

    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message,
    priority: 2

  });

  chrome.storage.local.set({ [key]: true });

}


/* ---------------------------------- */
/*     REQUEST MERGED CODE (inject)   */
/* ---------------------------------- */

async function getCombinedFromTab(tabId, retries = 3) {

  for (let i = 0; i < retries; i++) {

    console.log(`[🧠BG] 🛰️ REQUEST_COMBINED_CODE to tab ${tabId} (try ${i + 1}/${retries})`);

    try {

      const response = await chrome.tabs.sendMessage(tabId, { type: "REQUEST_COMBINED_CODE" });

      if (response && response.code) {

        console.log(`[🧠BG] 📦 Received combined code (${response.code.length} chars)`);

        return response.code;

      }

    } catch (err) {

      console.warn(`[🧠BG] ⚠️ Attempt ${i + 1} failed`, err.message);

    }

    await new Promise(r => setTimeout(r, 500));

  }

  console.error(`[🧠BG] ❌ No combined code after ${retries} retries`);

  return null;

}


/* ---------------------------------- */
/*     SAFE CSP-BYPASS EXECUTION      */
/* ---------------------------------- */

async function executeCombinedScript(tabId, code) {

  console.log(`[🧠BG] 🚀 Executing combined script (CSP-bypass MAIN world)...`);

  try {

    await chrome.scripting.executeScript({

      target: { tabId },

      world: "MAIN",

      func: (codeToExecute) => {

        try {

          const s = document.createElement("script");

          s.textContent = codeToExecute;

          document.documentElement.appendChild(s);

          s.remove();

          console.log("[🚀] Combined script executed successfully.");

        } catch (err) {

          console.error("[🚀] Script injection failed:", err);

        }

      },

      args: [code]

    });

  } catch (err) {

    console.error("💥 Combined script execution failed:", err);

  }

}


/* ---------------------------------- */
/*           HANDSHAKE LISTENER       */
/* ---------------------------------- */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === "INJECT_READY") {

    console.log(`[🧠BG] 🤝 Inject script ready (tab ${sender.tab?.id})`);

  }

  return true;

});


/* ---------------------------------- */
/*               ROUTER               */
/* ---------------------------------- */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  /* ------------ POPUP CHECK ---------- */

  if (msg.type === "CHECK_STATUS") {

    console.log("📩 Popup requested device status");

    (async () => {

      const info = await getLocalDeviceInfo();

      if (!info) {

        sendResponse({ approved: false, deviceId: null, source: "no-app" });

        return;

      }

      const approved = await isDeviceApproved(info.deviceId);

      sendResponse({

        approved,
        deviceId: info.deviceId,
        source: "local-app"

      });

    })();

    return true;

  }


  /* ------------ PAGE READY ------------ */

  if (msg.type === "PAGE_READY") {

    console.log("🌐 PAGE_READY received — initializing...");

    (async () => {

      const info = await getLocalDeviceInfo();

      if (!info) {

        chrome.storage.local.set({ deviceApproved: false, deviceId: null });

        await showNotificationOnce(
          "Local App Not Found",
          "Please open the Spidey Device Registration app.",
          "shownAppMissing"
        );

        return;

      }

      const { deviceId, approved, username, deviceName } = info;

      chrome.storage.local.set({

        deviceId,
        deviceApproved: approved,
        username: username || "",
        deviceName: deviceName || ""

      });

      const liveApproved = await isDeviceApproved(deviceId);

      if (liveApproved) {

        console.log("✅ Device approved:", deviceId);

        await showNotificationOnce(
          "Device Approved",
          "Your device is now fully active.",
          "shownApprovedNotification"
        );

        if (sender.tab?.id) {

          const tabId = sender.tab.id;

          console.log(`[🧠BG] Requesting combined code from tab ${tabId}...`);

          const combined = await getCombinedFromTab(tabId);

          if (!combined) return;

          await executeCombinedScript(tabId, combined);

        }

      } else {

        console.warn("🚫 Device not approved:", deviceId);

        await showNotificationOnce(
          "Approval Pending",
          "Please contact admin.",
          "shownPendingNotification"
        );

      }

    })();

    return true;

  }

  return true;

});