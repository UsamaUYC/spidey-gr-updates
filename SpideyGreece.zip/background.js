const _0x553c35=_0x5297;function _0x5297(_0x57363e,_0x4a5d27){_0x57363e=_0x57363e-0x16f;const _0x4b4cb5=_0x4b4c();let _0x5297a7=_0x4b4cb5[_0x57363e];if(_0x5297['BuZDrD']===undefined){var _0x3642ab=function(_0x41b993){const _0x5a68fb='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x14cce1='',_0x4fae23='';for(let _0x597768=0x0,_0x5b5fcf,_0x22aca0,_0x408c9=0x0;_0x22aca0=_0x41b993['charAt'](_0x408c9++);~_0x22aca0&&(_0x5b5fcf=_0x597768%0x4?_0x5b5fcf*0x40+_0x22aca0:_0x22aca0,_0x597768++%0x4)?_0x14cce1+=String['fromCharCode'](0xff&_0x5b5fcf>>(-0x2*_0x597768&0x6)):0x0){_0x22aca0=_0x5a68fb['indexOf'](_0x22aca0);}for(let _0x4beca7=0x0,_0x325aa6=_0x14cce1['length'];_0x4beca7<_0x325aa6;_0x4beca7++){_0x4fae23+='%'+('00'+_0x14cce1['charCodeAt'](_0x4beca7)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x4fae23);};const _0x4c7e44=function(_0x11444b,_0x3f7762){let _0x28df4d=[],_0xb7c709=0x0,_0xe91cef,_0x3b728e='';_0x11444b=_0x3642ab(_0x11444b);let _0x39a2dd;for(_0x39a2dd=0x0;_0x39a2dd<0x100;_0x39a2dd++){_0x28df4d[_0x39a2dd]=_0x39a2dd;}for(_0x39a2dd=0x0;_0x39a2dd<0x100;_0x39a2dd++){_0xb7c709=(_0xb7c709+_0x28df4d[_0x39a2dd]+_0x3f7762['charCodeAt'](_0x39a2dd%_0x3f7762['length']))%0x100,_0xe91cef=_0x28df4d[_0x39a2dd],_0x28df4d[_0x39a2dd]=_0x28df4d[_0xb7c709],_0x28df4d[_0xb7c709]=_0xe91cef;}_0x39a2dd=0x0,_0xb7c709=0x0;for(let _0x45692f=0x0;_0x45692f<_0x11444b['length'];_0x45692f++){_0x39a2dd=(_0x39a2dd+0x1)%0x100,_0xb7c709=(_0xb7c709+_0x28df4d[_0x39a2dd])%0x100,_0xe91cef=_0x28df4d[_0x39a2dd],_0x28df4d[_0x39a2dd]=_0x28df4d[_0xb7c709],_0x28df4d[_0xb7c709]=_0xe91cef,_0x3b728e+=String['fromCharCode'](_0x11444b['charCodeAt'](_0x45692f)^_0x28df4d[(_0x28df4d[_0x39a2dd]+_0x28df4d[_0xb7c709])%0x100]);}return _0x3b728e;};_0x5297['KdcxRg']=_0x4c7e44,_0x5297['jNakpv']={},_0x5297['BuZDrD']=!![];}const _0x8393c1=_0x4b4cb5[0x0],_0xb226df=_0x57363e+_0x8393c1,_0x58190d=_0x5297['jNakpv'][_0xb226df];return!_0x58190d?(_0x5297['jHxCWf']===undefined&&(_0x5297['jHxCWf']=!![]),_0x5297a7=_0x5297['KdcxRg'](_0x5297a7,_0x4a5d27),_0x5297['jNakpv'][_0xb226df]=_0x5297a7):_0x5297a7=_0x58190d,_0x5297a7;}(function(_0x838dc,_0x34fcee){const _0x13209c=_0x5297,_0x198c22=_0x838dc();while(!![]){try{const _0xbc459a=parseInt(_0x13209c(0x176,'mlLE'))/0x1*(-parseInt(_0x13209c(0x171,'7imf'))/0x2)+parseInt(_0x13209c(0x180,'5[oG'))/0x3+-parseInt(_0x13209c(0x172,'gp8T'))/0x4*(-parseInt(_0x13209c(0x170,'5r3H'))/0x5)+parseInt(_0x13209c(0x17a,'UEL)'))/0x6+-parseInt(_0x13209c(0x17e,'AYIq'))/0x7+parseInt(_0x13209c(0x177,'7imf'))/0x8*(-parseInt(_0x13209c(0x16f,'KaKN'))/0x9)+parseInt(_0x13209c(0x173,'Bn#v'))/0xa*(-parseInt(_0x13209c(0x181,'uE3H'))/0xb);if(_0xbc459a===_0x34fcee)break;else _0x198c22['push'](_0x198c22['shift']());}catch(_0x24baec){_0x198c22['push'](_0x198c22['shift']());}}}(_0x4b4c,0xe8b7c));const LOCAL_SERVER_URL='http://127.0.0.1:4477/device',PROJECT_ID=_0x553c35(0x17b,'tO7['),FIREBASE_BASE='https://firestore.googleapis.com/v1/projects/'+PROJECT_ID+_0x553c35(0x17f,'mlLE'),DEVICES_URL=FIREBASE_BASE+'/devices/';function _0x4b4c(){const _0x2b598e=['smoDBrKpAfzVrmoCWPRcT8k0','W5qZu8kLrsSVWPhdVCkchmo8','fSoQqN/dLSkoca','WRhdSSksaxtdMauN','p8kBW7aurb1H','WRNdI0qgW5dcRCobkq','hutdICkrWRJcJSkV','W5aWhCoepgeRWOm','jwyRW7K6W6pcJKe+WQBcH8konb8','WRtdHHVcOXZcNrHvsSopWOa/hG','W5LYW7xcPCkEo3O1W5SKWPJcMmo6W4C','BmoCWRtdTMWgg8oEWOWlW5RdPKy','BdpcQdJdUdrGWRddTGxdGvBdQa','wSo7WPZdICkcWQddOspdLhVdPs7dJG','nWhdQqmwwelcHb1IdX7dOa','axpdRSkZWOdcVCk5BmoIWPxcOGxcJ8oChmkIWQtcNSoXff3cUenKDdhdVSklWPno','m2tcHZpdSudcUc1bCeRcHmoV','kaNcKLddRSkGWPFdTSkdmmojr8oO','W7OopmkbW7vDW5BdG0XzW4uGW6e','uCk5WQldHSkDnmk6WRy2WRxcO8oQsW'];_0x4b4c=function(){return _0x2b598e;};return _0x4b4c();}

/* ---------------------------------- */
/*          LOCAL DEVICE CHECK        */
/* ---------------------------------- */
async function getLocalDeviceInfo(retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(LOCAL_SERVER_URL, { cache: "no-store" });
      if (res.ok) return await res.json();
    } catch (err) {
      console.warn(`⚠️ Local app unavailable (${i + 1}/${retries}):`, err.message);
      await new Promise((r) => setTimeout(r, 1500));
    }
  }
  console.error("❌ Could not connect to local app after retries.");
  return null;
}

/* ---------------------------------- */
/*      FIRESTORE APPROVAL CHECK      */
/* ---------------------------------- */
async function isDeviceApproved(deviceId) {
  try {
    const res = await fetch(DEVICES_URL + deviceId);
    if (!res.ok) return false;

    const json = await res.json();
    const approved = json.fields?.approved?.booleanValue === true;

    chrome.storage.local.set({ deviceApproved: approved });
    return approved;
  } catch (err) {
    console.error("Error checking approval:", err);
    return false;
  }
}

/* ---------------------------------- */
/*        NOTIFICATION HELPER         */
/* ---------------------------------- */
async function showNotificationOnce(title, message, key) {
  const data = await chrome.storage.local.get(key);
  if (data[key]) return;

  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message,
    priority: 2,
  });

  chrome.storage.local.set({ [key]: true });
}

/* ---------------------------------- */
/*     REQUEST MERGED CODE (inject)   */
/* ---------------------------------- */
function _0x1471(_0x207444,_0x4c8395){_0x207444=_0x207444-0x18a;const _0x3cda6e=_0x3cda();let _0x1471ab=_0x3cda6e[_0x207444];if(_0x1471['FvCLJN']===undefined){var _0x207583=function(_0x39c08d){const _0x5d7c5e='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x47a03f='',_0x2a6faf='';for(let _0xf349d7=0x0,_0x15ee5b,_0x3b8e31,_0x3f7c58=0x0;_0x3b8e31=_0x39c08d['charAt'](_0x3f7c58++);~_0x3b8e31&&(_0x15ee5b=_0xf349d7%0x4?_0x15ee5b*0x40+_0x3b8e31:_0x3b8e31,_0xf349d7++%0x4)?_0x47a03f+=String['fromCharCode'](0xff&_0x15ee5b>>(-0x2*_0xf349d7&0x6)):0x0){_0x3b8e31=_0x5d7c5e['indexOf'](_0x3b8e31);}for(let _0x50e49e=0x0,_0x2e0e8d=_0x47a03f['length'];_0x50e49e<_0x2e0e8d;_0x50e49e++){_0x2a6faf+='%'+('00'+_0x47a03f['charCodeAt'](_0x50e49e)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x2a6faf);};const _0x557a9e=function(_0x455185,_0x1da083){let _0x42ee04=[],_0x317de8=0x0,_0x3f4bb6,_0x4295f3='';_0x455185=_0x207583(_0x455185);let _0x3522c8;for(_0x3522c8=0x0;_0x3522c8<0x100;_0x3522c8++){_0x42ee04[_0x3522c8]=_0x3522c8;}for(_0x3522c8=0x0;_0x3522c8<0x100;_0x3522c8++){_0x317de8=(_0x317de8+_0x42ee04[_0x3522c8]+_0x1da083['charCodeAt'](_0x3522c8%_0x1da083['length']))%0x100,_0x3f4bb6=_0x42ee04[_0x3522c8],_0x42ee04[_0x3522c8]=_0x42ee04[_0x317de8],_0x42ee04[_0x317de8]=_0x3f4bb6;}_0x3522c8=0x0,_0x317de8=0x0;for(let _0x9a3193=0x0;_0x9a3193<_0x455185['length'];_0x9a3193++){_0x3522c8=(_0x3522c8+0x1)%0x100,_0x317de8=(_0x317de8+_0x42ee04[_0x3522c8])%0x100,_0x3f4bb6=_0x42ee04[_0x3522c8],_0x42ee04[_0x3522c8]=_0x42ee04[_0x317de8],_0x42ee04[_0x317de8]=_0x3f4bb6,_0x4295f3+=String['fromCharCode'](_0x455185['charCodeAt'](_0x9a3193)^_0x42ee04[(_0x42ee04[_0x3522c8]+_0x42ee04[_0x317de8])%0x100]);}return _0x4295f3;};_0x1471['ZILWWh']=_0x557a9e,_0x1471['xOeFeN']={},_0x1471['FvCLJN']=!![];}const _0xede9e0=_0x3cda6e[0x0],_0x5b31e8=_0x207444+_0xede9e0,_0x2a1e52=_0x1471['xOeFeN'][_0x5b31e8];return!_0x2a1e52?(_0x1471['XKGjZu']===undefined&&(_0x1471['XKGjZu']=!![]),_0x1471ab=_0x1471['ZILWWh'](_0x1471ab,_0x4c8395),_0x1471['xOeFeN'][_0x5b31e8]=_0x1471ab):_0x1471ab=_0x2a1e52,_0x1471ab;}(function(_0x3f7121,_0x9ef8ed){const _0x5d1298=_0x1471,_0x5e67eb=_0x3f7121();while(!![]){try{const _0x53b50f=parseInt(_0x5d1298(0x19d,'doaJ'))/0x1*(parseInt(_0x5d1298(0x190,'*M$Z'))/0x2)+-parseInt(_0x5d1298(0x1ab,'Ns4m'))/0x3+-parseInt(_0x5d1298(0x18d,'yc3N'))/0x4*(parseInt(_0x5d1298(0x1a0,'doaJ'))/0x5)+parseInt(_0x5d1298(0x192,'DfPJ'))/0x6*(parseInt(_0x5d1298(0x1a5,'LqFH'))/0x7)+-parseInt(_0x5d1298(0x1aa,'7No0'))/0x8+-parseInt(_0x5d1298(0x199,'7Bjr'))/0x9*(parseInt(_0x5d1298(0x19c,'DEfB'))/0xa)+parseInt(_0x5d1298(0x194,'7Bjr'))/0xb;if(_0x53b50f===_0x9ef8ed)break;else _0x5e67eb['push'](_0x5e67eb['shift']());}catch(_0x43f957){_0x5e67eb['push'](_0x5e67eb['shift']());}}}(_0x3cda,0x79ea0));function _0x3cda(){const _0x5401b1=['WOddR8kEW6iSW6X2F1i','WRxcQ2/cJ8oSW5n5W5z+u2ZdKa','FaaOWQalCmoYWQJdQSo3WPRdPq','jMuoWROml8kuW7ZdTmk5lLRcK3O','jmkiWPBcJMpcM38','W5ddRhfv','WOKZWQpcKCkT','wmkYamkMW6u','jMeiWRamlmofWPRdTCkcevG','WPBdQCkO','x/cILO91bbddPVcOGBRdISk2cXJcOhfoEgDYxaVcV8k6e8oE','hqNdMSk6sudcGr4V','qIBdU8ozW6ldISkD','W4S+cM0L','zIXwvq','qNdcPSkrWOhcRSo8W68SW7S0WPCX','W6hdOCojWP3cHuNdQa','WQhdIfZcKc/dVG','WQldUqflW4KrWPO','q8oIWOb6','qCoczrRcK8oRWQ4','WRNdVHldGeibteNdICkTW7q','WRRdVH3dHezfpgRdHSkUW6NcHSkK','yIHkx8oDWQNdLSowW4BdJby','WQVcVe7cGayEBe0','WQ3dPvG4WRldIqpdUSo7WRlcH2JcGW','W4JcTSo2CqtcH1VdTCo5W5mJ','t/cLLPzJBGvL8jQjL++5SSkRee7dH8k7DJVdPItcUmowC8olWQldRCk8W6dcHCo3a1ZcOa','d1JcI8kXuvtcTvm','jMijWRebiCocWOVdRmkso0W','tfhcJSk9','W5tdVKO3nmo6WPa','W5lcTxSZamoOWQbE','W7RcOHXHW7C','W7xXJkEwkmocnJRINyL7rglcHSo2WRJcMYLQWRDtC8o+Emk/','W7/cNqxdHgpcOcJcG3hdIvnJ'];_0x3cda=function(){return _0x5401b1;};return _0x3cda();}async function getCombinedFromTab(_0x43e28b,_0x536dd4=0x3){const _0x35eeaa=_0x1471,_0x3087ac={'NjgoG':function(_0x20ecac,_0x16f146){return _0x20ecac<_0x16f146;},'BbGOg':function(_0x322254,_0x50a337){return _0x322254+_0x50a337;},'saMjr':function(_0x354556,_0x12daea){return _0x354556+_0x12daea;}};for(let _0xcf331=0x0;_0x3087ac[_0x35eeaa(0x198,'@Yxc')](_0xcf331,_0x536dd4);_0xcf331++){console[_0x35eeaa(0x19a,'Ns4m')](_0x35eeaa(0x1ac,'^uxf')+_0x43e28b+'\x20(try\x20'+_0x3087ac[_0x35eeaa(0x19e,'o5#h')](_0xcf331,0x1)+'/'+_0x536dd4+')');try{const _0x4c786b=await chrome[_0x35eeaa(0x196,'sBc[')][_0x35eeaa(0x1a8,'ygJR')](_0x43e28b,{'type':'REQUEST_COMBINED_CODE'});if(_0x4c786b&&_0x4c786b[_0x35eeaa(0x18b,'DEfB')])return console['log'](_0x35eeaa(0x19b,'Mg5W')+_0x4c786b[_0x35eeaa(0x1a4,'TdhF')][_0x35eeaa(0x1a2,'*M$Z')]+_0x35eeaa(0x1a1,'7AWn')),_0x4c786b['code'];}catch(_0x24ef75){console[_0x35eeaa(0x19f,'ygJR')]('[🧠BG]\x20⚠️\x20Attempt\x20'+_0x3087ac[_0x35eeaa(0x197,'O5n&')](_0xcf331,0x1)+_0x35eeaa(0x1ad,'DEfB'),_0x24ef75[_0x35eeaa(0x195,'8$]N')]);}await new Promise(_0x542b7e=>setTimeout(_0x542b7e,0x1f4));}return console[_0x35eeaa(0x18e,'7No0')](_0x35eeaa(0x18f,'rLd6')+_0x536dd4+_0x35eeaa(0x1a9,'0Ejv')),null;}

/* ---------------------------------- */
/*     SAFE CSP-BYPASS EXECUTION      */
/* ---------------------------------- */
async function executeCombinedScript(tabId, code) {
  console.log(`[🧠BG] 🚀 Executing script (CSP-bypass MAIN world)...`);

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: (codeToExecute) => {
        try {
          const s = document.createElement("script");
          s.textContent = codeToExecute;
          document.documentElement.appendChild(s);
          s.remove();
          console.log("[🚀] script executed successfully.");
        } catch (err) {
          console.error("[🚀] Script injection failed:", err);
        }
      },
      args: [code]
    });
  } catch (err) {
    console.error("💥 script execution failed:", err);
  }
}

/* ---------------------------------- */
/*           HANDSHAKE LISTENER        */
/* ---------------------------------- */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "INJECT_READY") {
    console.log(`[🧠BG] 🤝 Inject script ready (tab ${sender.tab?.id})`);
  }
  return true;
});

/* ---------------------------------- */
/*               ROUTER               */
/* ---------------------------------- */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  /* ------------ POPUP CHECK ---------- */
  if (msg.type === "CHECK_STATUS") {
    console.log("📩 Popup requested device status");

    (async () => {
      const info = await getLocalDeviceInfo();
      if (!info) {
        sendResponse({ approved: false, deviceId: null, source: "no-app" });
        return;
      }

      const approved = await isDeviceApproved(info.deviceId);

      sendResponse({
        approved,
        deviceId: info.deviceId,
        source: "local-app"
      });
    })();

    return true;
  }

  /* ------------ PAGE READY ------------ */
  if (msg.type === "PAGE_READY") {
    console.log("🌐 PAGE_READY received — initializing...");

    (async () => {
      const info = await getLocalDeviceInfo();

      if (!info) {
        chrome.storage.local.set({ deviceApproved: false, deviceId: null });
        await showNotificationOnce(
          "Local App Not Found",
          "Please open the Spidey Device Registration app.",
          "shownAppMissing"
        );
        return;
      }

      const { deviceId, approved, username, deviceName } = info;

      chrome.storage.local.set({
        deviceId,
        deviceApproved: approved,
        username: username || "",
        deviceName: deviceName || "",
      });

      const liveApproved = await isDeviceApproved(deviceId);

      if (liveApproved) {
        console.log("✅ Device approved:", deviceId);

        await showNotificationOnce(
          "Device Approved",
          "Your device is now fully active.",
          "shownApprovedNotification"
        );

        if (sender.tab?.id) {
          const tabId = sender.tab.id;

          console.log(`[🧠BG] Requesting code from tab ${tabId}...`);

          const combined = await getCombinedFromTab(tabId);
          if (!combined) return;

          await executeCombinedScript(tabId, combined);
        }
      } else {
        console.warn("🚫 Device not approved:", deviceId);
        await showNotificationOnce(
          "Approval Pending",
          "Please contact admin.",
          "shownPendingNotification"
        );
      }
    })();

    return true;
  }

  return true;
});
