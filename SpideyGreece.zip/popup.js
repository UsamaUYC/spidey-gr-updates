document.addEventListener("DOMContentLoaded", () => {
  const statusBox = document.getElementById("statusBox");
  const refreshBtn = document.getElementById("refreshBtn");

  /** Update UI based on approval */
  function setStatus(approved, connected = true) {
    if (!connected) {
      statusBox.textContent = "⚠️ Cannot connect to app";
      statusBox.style.color = "red";
      return;
    }
    if (approved === true) {
      statusBox.textContent = "✅ Device Approved";
      statusBox.style.color = "green";
    } else if (approved === false) {
      statusBox.textContent = "⏳ Waiting for approval";
      statusBox.style.color = "#b58900";
    } else {
      statusBox.textContent = "⚙️ Checking...";
      statusBox.style.color = "#444";
    }
  }

  /** Query background for status */
  async function refreshStatus() {
    refreshBtn.disabled = true;
    refreshBtn.textContent = "Refreshing...";
    try {
      const response = await chrome.runtime.sendMessage({ type: "CHECK_STATUS" });
      if (response && response.source === "local-app") {
        setStatus(response.approved, true);
      } else {
        setStatus(false, false);
      }
    } catch (err) {
      console.error("Popup refresh failed:", err);
      setStatus(false, false);
    } finally {
      refreshBtn.disabled = false;
      refreshBtn.textContent = "🔄 Refresh Status";
    }
  }

  // Load cached state first
  chrome.storage.local.get(["deviceApproved"], (data) => {
    setStatus(data.deviceApproved);
  });

  // Refresh immediately
  refreshStatus();

  // Refresh button click
  refreshBtn.addEventListener("click", refreshStatus);
});
